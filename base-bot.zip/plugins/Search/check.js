const axios = require("axios");
const { blazetz } = require("../../devblaze/blazetz");

// VERIFIED CONTACT
const quotedContact = {
  key: {
    fromMe: false,
    participant: "0@s.whatsapp.net",
    remoteJid: "status@broadcast",
  },
  message: {
    contactMessage: {
      displayName: "BLAZE VERIFIED ✅",
      vcard:
        "BEGIN:VCARD\nVERSION:3.0\nFN:BLAZE VERIFIED ✅\nORG:BLAZE-TECH BOT;\nTEL;type=CELL;type=VOICE;waid=255627417402:+255627417402\nEND:VCARD",
    },
  },
};

// NEWSLETTER CONTEXT
const newsletterContext = {
  forwardingScore: 999,
  isForwarded: true,
  forwardedNewsletterMessageInfo: {
    newsletterJid: "120363421014261315@newsletter",
    newsletterName: "𝙱𝙻𝙰𝚉𝙴 𝚇𝙼𝙳",
    serverMessageId: 1,
  },
};

// FLAG EMOJI
function getFlagEmoji(countryCode) {
  if (!countryCode) return "";
  return countryCode
    .toUpperCase()
    .split("")
    .map((letter) =>
      String.fromCodePoint(letter.charCodeAt(0) + 127397)
    )
    .join("");
}

blazetz(
  {
    nomCom: "check",
    categorie: "Search",
    reaction: "🌍",
  },
  async (dest, client, { arg, ms, repondre }) => {
    try {
      let code = arg[0];

      if (!code) {
        return repondre(
          "❌ Please provide a country code.\nExample: `.check 255`"
        );
      }

      // Remove + and spaces
      code = code.replace(/\+/g, "").trim();

      const API_URL = "https://blaze-countries-api.vercel.app/api";

      const response = await axios.get(API_URL, {
        timeout: 10000,
      });

      const countries = response.data;

      if (!Array.isArray(countries)) {
        return repondre("❌ Invalid API response.");
      }

      // Flexible match
      const matches = countries.filter(
        (c) =>
          c.calling_code &&
          c.calling_code.replace(/\+/g, "") === code
      );

      if (matches.length === 0) {
        return repondre(
          `❌ No country found for code +${code}`
        );
      }

      const countryList = matches
        .map(
          (c) =>
            `${getFlagEmoji(c.code)} ${c.name}`
        )
        .join("\n");

      const message = `🌍 *COUNTRY CODE CHECKER*
━━━━━━━━━━━━━━━━━━
📞 *Code:* +${code}

🌎 *Country List:*
${countryList}

_By BLAZE-XMD_`;

      await client.sendMessage(
        dest,
        {
          text: message,
          contextInfo: {
            ...newsletterContext,
          },
        },
        { quoted: quotedContact }
      );
    } catch (error) {
      console.log("API ERROR:", error.message);
      repondre("❌ Failed to fetch country data. Try again later.");
    }
  }
);
